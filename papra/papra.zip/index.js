var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// papra/src/index.js
var index_exports = {};
__export(index_exports, {
  activate: () => activate,
  hooks: () => hooks,
  slots: () => slots
});
module.exports = __toCommonJS(index_exports);
var import_react4 = require("react");

// papra/src/lib/errors.js
var PapraError = class extends Error {
  /**
   * @param {string} key  i18n key, e.g. 'error.key'
   * @param {Record<string, string|number>} [vars]
   * @param {number} [status] HTTP status, when there was one
   */
  constructor(key, vars = {}, status = 0) {
    super(key);
    this.name = "PapraError";
    this.key = key;
    this.vars = vars;
    this.status = status;
  }
};
function oneLine(text) {
  const flat = String(text).replace(/\s+/g, " ").trim();
  return flat.length > 200 ? `${flat.slice(0, 197)}...` : flat;
}
function parse(body) {
  if (body && typeof body === "object") return body;
  if (typeof body !== "string" || !/^\s*[{[]/.test(body)) return null;
  try {
    return JSON.parse(body);
  } catch {
    return null;
  }
}
function papraError(body) {
  const err = parse(body)?.error;
  if (!err || typeof err !== "object") return { message: "", code: "" };
  return {
    message: typeof err.message === "string" ? oneLine(err.message) : "",
    code: typeof err.code === "string" ? err.code : ""
  };
}
function retryAfter(headers) {
  const seconds = Number(headers?.["retry-after"]);
  return Number.isFinite(seconds) && seconds > 0 ? Math.ceil(seconds) : 0;
}
function errorFromResponse(res) {
  if (res.proxyError) {
    switch (res.proxyError) {
      case "no_credential":
        return new PapraError("error.not_connected", {}, res.status);
      case "rate_limited":
        return new PapraError("error.rate_limit", { seconds: retryAfter(res.headers) || 60 }, 429);
      case "timeout":
        return new PapraError("error.timeout", {}, 504);
      case "unreachable":
        return new PapraError("error.unreachable", {}, 502);
      case "blocked_address":
        return new PapraError("error.blocked", {}, 403);
      case "too_large":
        return new PapraError("error.too_large", {}, 413);
      case "wrong_origin":
        return new PapraError("error.wrong_server", {}, 403);
      default:
        return new PapraError("error.proxy", { detail: papraError(res.body).message || res.proxyError }, res.status);
    }
  }
  const { status } = res;
  const { message, code } = papraError(res.body);
  if (status === 401) return new PapraError("error.key", {}, status);
  if (status === 403) return new PapraError("error.forbidden", {}, status);
  if (status === 404) return new PapraError("error.not_found", {}, status);
  if (status === 409 && code === "document.already_exists") return new PapraError("error.duplicate", {}, status);
  if (status === 413) return new PapraError("error.too_large", {}, status);
  if (status === 429) return new PapraError("error.rate_limit", { seconds: retryAfter(res.headers) || 60 }, status);
  if (status === 502 || status === 503 || status === 504) return new PapraError("error.unavailable", {}, status);
  if (status >= 500) return new PapraError("error.server", {}, status);
  if (status >= 400) return new PapraError("error.rejected", { detail: message || `HTTP ${status}` }, status);
  return new PapraError("error.unexpected", { detail: `HTTP ${status}` }, status);
}
function toPapraError(err) {
  if (err instanceof PapraError) return err;
  const message = err && typeof err.message === "string" ? err.message : String(err);
  if (/timed out|timeout/i.test(message)) return new PapraError("error.timeout");
  if (/cancel|abort/i.test(message)) return new PapraError("error.cancelled");
  if (/larger than/i.test(message)) return new PapraError("error.too_large");
  if (/permission|not allowed|not granted/i.test(message)) return new PapraError("error.permission");
  if (/network|failed to fetch/i.test(message)) return new PapraError("error.unreachable");
  return new PapraError("error.unexpected", { detail: oneLine(message.split(/\r?\n/)[0]) });
}
function errorText(t, err) {
  const e = toPapraError(err);
  return t(e.key, e.vars);
}

// papra/src/lib/multipart.js
function quote(value) {
  return String(value).replace(/[\r\n]+/g, " ").replace(/(["\\])/g, "\\$1");
}
function randomBoundary() {
  let out = "----BulwarkPapra";
  for (let i = 0; i < 24; i++) out += Math.floor(Math.random() * 36).toString(36);
  return out;
}
function toBytes(data) {
  if (data instanceof Uint8Array) return data;
  if (data instanceof ArrayBuffer) return new Uint8Array(data);
  if (ArrayBuffer.isView(data)) return new Uint8Array(data.buffer, data.byteOffset, data.byteLength);
  return new TextEncoder().encode(String(data));
}
function buildMultipart(fields, boundary = randomBoundary()) {
  const enc2 = new TextEncoder();
  const chunks = [];
  for (const [name, value] of fields) {
    if (value === void 0 || value === null) continue;
    let head = `--${boundary}\r
Content-Disposition: form-data; name="${quote(name)}"`;
    if (typeof value === "object" && "data" in value) {
      head += `; filename="${quote(value.filename || "document")}"\r
Content-Type: ${value.type || "application/octet-stream"}\r
\r
`;
      chunks.push(enc2.encode(head), toBytes(value.data), enc2.encode("\r\n"));
    } else {
      head += "\r\n\r\n";
      chunks.push(enc2.encode(head), enc2.encode(String(value)), enc2.encode("\r\n"));
    }
  }
  chunks.push(enc2.encode(`--${boundary}--\r
`));
  const size = chunks.reduce((n, c) => n + c.byteLength, 0);
  const body = new Uint8Array(size);
  let offset = 0;
  for (const c of chunks) {
    body.set(c, offset);
    offset += c.byteLength;
  }
  return { body, contentType: `multipart/form-data; boundary=${boundary}` };
}

// papra/src/lib/client.js
var PAGE_SIZE = 25;
var MAX_PAGE_SIZE = 100;
function normalizeBase(value) {
  if (typeof value !== "string" || !value.trim()) return "";
  let text = value.trim();
  if (!/^[a-z][a-z0-9+.-]*:\/\//i.test(text)) text = `https://${text}`;
  try {
    const url = new URL(text);
    if (url.protocol !== "https:" && url.protocol !== "http:") return "";
    const path = url.pathname.replace(/\/+$/, "").replace(/\/api$/, "");
    return `${url.origin}${path}`;
  } catch {
    return "";
  }
}
function searchQuery(text = "", tags = []) {
  const parts = [];
  const words = String(text || "").trim();
  if (words) parts.push(words);
  for (const tag of tags) {
    const name = String(tag ?? "").replace(/"/g, "").trim();
    if (name) parts.push(`tag:"${name}"`);
  }
  return parts.join(" ");
}
var tagOf = (t) => ({ id: String(t?.id ?? ""), name: String(t?.name ?? ""), color: typeof t?.color === "string" ? t.color : "" });
function documentOf(d) {
  return {
    id: String(d?.id ?? ""),
    name: String(d?.name ?? d?.originalName ?? ""),
    mimeType: typeof d?.mimeType === "string" && d.mimeType ? d.mimeType : "application/octet-stream",
    size: Number.isFinite(d?.originalSize) ? d.originalSize : 0,
    createdAt: typeof d?.createdAt === "string" ? d.createdAt : "",
    documentDate: typeof d?.documentDate === "string" ? d.documentDate : "",
    tags: Array.isArray(d?.tags) ? d.tags.map(tagOf) : []
  };
}
function filenameFromDisposition(header) {
  if (typeof header !== "string") return "";
  const star = /filename\*\s*=\s*([^']*)'[^']*'([^;]+)/i.exec(header);
  if (star) {
    try {
      return decodeURIComponent(star[2].trim());
    } catch {
    }
  }
  const plain = /filename\s*=\s*"((?:[^"\\]|\\.)*)"|filename\s*=\s*([^;]+)/i.exec(header);
  if (plain) return (plain[1] ?? plain[2] ?? "").replace(/\\(.)/g, "$1").trim();
  return "";
}
var enc = encodeURIComponent;
function createClient({ proxyFetch, credentialId, base }) {
  if (!base) throw new PapraError("error.not_configured");
  async function request(path, { method = "GET", headers = {}, body, responseType = "text", signal, onProgress } = {}) {
    const init = { method, headers: { Accept: "application/json", ...headers }, responseType };
    if (body !== void 0) init.body = body;
    if (signal) init.signal = signal;
    if (onProgress) init.onProgress = onProgress;
    const res = await proxyFetch(credentialId, `${base}${path}`, init);
    if (!res || !res.ok) throw errorFromResponse(res || { status: 0, headers: {} });
    return res;
  }
  async function json(path, opts) {
    const res = await request(path, opts);
    const text = typeof res.body === "string" ? res.body : "";
    if (!text) return null;
    try {
      return JSON.parse(text);
    } catch {
      throw new PapraError("error.not_papra", {}, res.status);
    }
  }
  const sendJson = (method, path, data) => json(path, {
    method,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data)
  });
  return {
    base,
    credentialId,
    /** The connected key's name and permissions; needs no permission, so it also checks the key. */
    async currentKey() {
      const key = (await json("/api/api-keys/current"))?.apiKey;
      if (!key || typeof key !== "object") throw new PapraError("error.not_papra");
      return {
        id: String(key.id ?? ""),
        name: String(key.name ?? ""),
        permissions: Array.isArray(key.permissions) ? key.permissions.filter((p) => typeof p === "string") : []
      };
    },
    /** The user's organisations, by name. Needs organizations:read. */
    async organizations() {
      const rows = (await json("/api/organizations"))?.organizations;
      return (Array.isArray(rows) ? rows : []).map((o) => ({ id: String(o?.id ?? ""), name: String(o?.name ?? "") })).filter((o) => o.id).sort((a, b) => a.name.localeCompare(b.name));
    },
    /** An organisation's tags, by name. Needs tags:read. */
    async tags(organizationId) {
      const rows = (await json(`/api/organizations/${enc(organizationId)}/tags`))?.tags;
      return (Array.isArray(rows) ? rows : []).map(tagOf).filter((t) => t.id).sort((a, b) => a.name.localeCompare(b.name));
    },
    /**
     * Full-text search in one organisation, newest first. `pageIndex` counts from 0.
     * Needs documents:read.
     */
    async searchDocuments(organizationId, { text = "", tags = [] } = {}, pageIndex = 0, pageSize = PAGE_SIZE) {
      const q = new URLSearchParams({
        searchQuery: searchQuery(text, tags),
        pageIndex: String(Math.max(0, Math.floor(pageIndex) || 0)),
        pageSize: String(Math.min(MAX_PAGE_SIZE, Math.max(1, Math.floor(pageSize) || PAGE_SIZE)))
      });
      const data = await json(`/api/organizations/${enc(organizationId)}/documents?${q}`);
      const rows = Array.isArray(data?.documents) ? data.documents : [];
      return { count: Number.isFinite(data?.documentsCount) ? data.documentsCount : rows.length, documents: rows.map(documentOf) };
    },
    /**
     * Upload a file as a new document. Needs documents:create.
     * @param {{ data: Uint8Array|ArrayBuffer, name: string, type?: string }} file
     */
    async upload(organizationId, file, { signal, onProgress } = {}) {
      const { body, contentType } = buildMultipart([["file", { filename: file.name, type: file.type, data: file.data }]]);
      const data = await json(`/api/organizations/${enc(organizationId)}/documents`, {
        method: "POST",
        headers: { "Content-Type": contentType },
        body,
        signal,
        onProgress
      });
      if (!data?.document?.id) throw new PapraError("error.not_papra");
      return documentOf(data.document);
    },
    /** Add a tag to a document. Needs documents:update and tags:read. */
    async tagDocument(organizationId, documentId, tagId) {
      await sendJson("POST", `/api/organizations/${enc(organizationId)}/documents/${enc(documentId)}/tags`, { tagId });
    },
    /**
     * A document's file. Papra serves every file as application/octet-stream,
     * so the type comes from the document (its search result). Needs documents:read.
     */
    async download(organizationId, doc) {
      const res = await request(`/api/organizations/${enc(organizationId)}/documents/${enc(doc.id)}/file`, { responseType: "arraybuffer" });
      const name = filenameFromDisposition(res.headers?.["content-disposition"]) || doc.name || "document";
      return { data: res.body, type: doc.mimeType || "application/octet-stream", name };
    }
  };
}

// papra/src/lib/connection.js
var CREDENTIAL = "papra";
var REQUIRED_PERMISSIONS = ["organizations:read", "documents:read", "documents:create"];
var TAGGING_PERMISSIONS = ["tags:read", "documents:update"];
var disconnect = (api) => Promise.resolve().then(() => api.proxy.disconnect(CREDENTIAL)).catch(() => {
});
var originOf = (url) => {
  try {
    return new URL(url).origin;
  } catch {
    return "";
  }
};
async function adminServer(api) {
  try {
    const config = await api.config.get();
    return normalizeBase(config?.serverUrl);
  } catch {
    return "";
  }
}
async function resolveConnection(api) {
  const server = await adminServer(api);
  if (!server) return { state: "not_configured" };
  let accounts = [];
  try {
    accounts = await api.proxy.accounts() || [];
  } catch {
    accounts = [];
  }
  const mine = accounts.find((a) => a?.credentialId === CREDENTIAL && a.connected);
  if (!mine) return { state: "disconnected", server };
  if (originOf(mine.origin) !== originOf(server)) {
    await disconnect(api);
    return { state: "disconnected", server, wrongServer: mine.origin };
  }
  return { state: "connected", server };
}
function clientFor(api, connection) {
  if (connection?.state === "not_configured") throw new PapraError("error.not_configured");
  if (connection?.state !== "connected") throw new PapraError("error.not_connected");
  return createClient({ proxyFetch: (...a) => api.proxy.fetch(...a), credentialId: CREDENTIAL, base: connection.server });
}
function keyAbilities(permissions = []) {
  const has = new Set(permissions);
  return {
    missing: REQUIRED_PERMISSIONS.filter((p) => !has.has(p)),
    canTag: TAGGING_PERMISSIONS.every((p) => has.has(p)),
    canReadTags: has.has("tags:read")
  };
}
async function checkKey(api, connection) {
  const key = await clientFor(api, connection).currentKey();
  return keyAbilities(key.permissions);
}
async function connect(api) {
  const server = await adminServer(api);
  if (!server) return { connected: false, error: new PapraError("error.not_configured") };
  const result = await api.proxy.connect(CREDENTIAL, { mode: "password", server });
  if (!result?.connected) return { connected: false };
  const drop = () => disconnect(api);
  if (result.origin && originOf(result.origin) !== originOf(server)) {
    await drop();
    return { connected: false, error: new PapraError("error.wrong_server_connect", { server: new URL(server).host }) };
  }
  const connection = await resolveConnection(api);
  if (connection.state !== "connected") return { connected: false };
  let abilities;
  try {
    abilities = await checkKey(api, connection);
  } catch (err) {
    const e = toPapraError(err);
    if (e.key === "error.key") await drop();
    return { connected: false, error: e };
  }
  if (abilities.missing.length) {
    await drop();
    return { connected: false, error: new PapraError("error.key_permissions", { missing: abilities.missing.join(", ") }) };
  }
  return { connected: true, connection, canTag: abilities.canTag, canReadTags: abilities.canReadTags };
}

// papra/src/lib/attach.js
var MAX_DOCUMENT_BYTES = 25 * 1024 * 1024;
async function attachDocuments({ api, client, organizationId, documents, composerId }) {
  const attached = [];
  const fail = (err) => {
    const e = toPapraError(err);
    e.attached = attached;
    return e;
  };
  for (const doc of documents) {
    if (doc.size > MAX_DOCUMENT_BYTES) throw fail(new PapraError("error.document_too_large", { name: doc.name }));
    let file;
    let blob;
    try {
      file = await client.download(organizationId, doc);
      blob = await api.jmap.uploadBlob(new Uint8Array(file.data), file.name, file.type);
    } catch (err) {
      throw fail(err);
    }
    let ok;
    try {
      ok = await api.composer.attach(composerId, { blobId: blob.blobId, name: file.name, type: blob.type || file.type, size: blob.size ?? file.data.byteLength });
    } catch (err) {
      throw fail(err);
    }
    if (ok === false) throw fail(new PapraError("error.attach_refused", { name: file.name }));
    attached.push(file.name);
  }
  return attached;
}

// papra/src/lib/save.js
var MAX_ATTACHMENT_BYTES = 25 * 1024 * 1024;
function attachmentOf(context) {
  const c = context || {};
  if (!c.emailId || !c.blobId) return null;
  return {
    emailId: String(c.emailId),
    blobId: String(c.blobId),
    name: typeof c.name === "string" && c.name.trim() ? c.name.trim() : "attachment",
    type: typeof c.type === "string" && c.type ? c.type : "application/octet-stream",
    size: Number.isFinite(c.size) ? c.size : 0
  };
}
async function saveAttachment({ api, client, attachment, organizationId, tagIds = [] }) {
  if (attachment.size > MAX_ATTACHMENT_BYTES) throw new PapraError("error.mail_too_large");
  let file;
  try {
    file = await api.email.getAttachment(attachment.emailId, attachment.blobId);
  } catch (err) {
    throw toPapraError(err);
  }
  const document = await client.upload(organizationId, {
    data: file.data,
    name: file.name || attachment.name,
    type: file.type || attachment.type
  });
  const tagged = [];
  let tagError = null;
  for (const tagId of tagIds) {
    try {
      await client.tagDocument(organizationId, document.id, tagId);
      tagged.push(tagId);
    } catch (err) {
      tagError = toPapraError(err);
      break;
    }
  }
  return { document, tagged, tagError };
}

// papra/src/lib/tags.js
function parseTagList(value) {
  const seen = /* @__PURE__ */ new Set();
  const out = [];
  for (const raw of String(value ?? "").split(",")) {
    const name = raw.trim();
    const key = name.toLowerCase();
    if (!name || seen.has(key)) continue;
    seen.add(key);
    out.push(name);
  }
  return out;
}
function matchTags(names, organizationTags) {
  const byName = new Map((organizationTags || []).map((t) => [t.name.toLowerCase(), t]));
  const tags = [];
  const missing = [];
  for (const name of names || []) {
    const tag = byName.get(name.toLowerCase());
    if (tag) tags.push(tag);
    else missing.push(name);
  }
  return { tags, missing };
}

// papra/src/lib/background.js
var ACTION_SAVE = "save-attachment";
var ACTION_ATTACH = "from-papra";
var DEFAULT_ORGANIZATION_KEY = "defaultOrganizationId";
var PROGRESS_FROM_BYTES = 1024 * 1024;
var hostOf = (url) => {
  try {
    return new URL(url).host;
  } catch {
    return String(url || "");
  }
};
function createBackground(api) {
  const t = (key, vars) => api.i18n.t(key, vars);
  const toastError = (err) => api.toast.error(errorText(t, err));
  async function ensureConnection() {
    let connection = await resolveConnection(api);
    if (connection.state === "not_configured") throw new PapraError("error.not_configured");
    if (connection.state === "disconnected") {
      const host = hostOf(connection.server);
      const message = connection.wrongServer ? t("connect.wrong_server", { server: hostOf(connection.wrongServer), host }) : t("connect.needed", { host });
      const go = await api.ui.confirm({ title: t("connect.title"), message, confirmLabel: t("connect.button"), cancelLabel: t("common.cancel") });
      if (!go) return null;
      const result = await connect(api);
      if (!result.connected) {
        if (result.error) throw result.error;
        return null;
      }
      return { connection: result.connection, canTag: result.canTag, canReadTags: result.canReadTags };
    }
    const { missing, canTag, canReadTags } = await checkKey(api, connection);
    if (missing.length) throw new PapraError("error.key_permissions", { missing: missing.join(", ") });
    return { connection, canTag, canReadTags };
  }
  async function showProgress(text) {
    try {
      const id = await api.toast.progress(text);
      return typeof id === "string" ? id : null;
    } catch {
      return null;
    }
  }
  function hideProgress(id) {
    if (id) Promise.resolve().then(() => api.toast.dismiss(id)).catch(() => {
    });
  }
  async function saveFlow(context) {
    const attachment = attachmentOf(context);
    if (!attachment) return null;
    try {
      const ready = await ensureConnection();
      if (!ready) return null;
      const { connection, canTag } = ready;
      const config = await Promise.resolve(api.config.get()).catch(() => ({}));
      const choice = await api.ui.openDialog({
        title: t("dialog.title"),
        slot: "plugin-dialog",
        width: 520,
        extraProps: {
          view: "save",
          attachment: { name: attachment.name, size: attachment.size },
          connection,
          canTag,
          defaultTags: parseTagList(config?.defaultTags),
          organizationId: await api.storage.get(DEFAULT_ORGANIZATION_KEY).catch(() => null)
        }
      });
      if (!choice?.organizationId) return null;
      const progress = attachment.size >= PROGRESS_FROM_BYTES ? await showProgress(t("save.saving", { name: attachment.name })) : null;
      let result;
      try {
        result = await saveAttachment({
          api,
          client: clientFor(api, connection),
          attachment,
          organizationId: choice.organizationId,
          tagIds: canTag ? choice.tagIds || [] : []
        });
      } finally {
        hideProgress(progress);
      }
      report(attachment, choice, result);
      return result;
    } catch (err) {
      const e = toPapraError(err);
      if (e.key === "error.duplicate") api.toast.info(t("done.duplicate", { name: attachment.name }));
      else toastError(e);
      return null;
    }
  }
  function report(attachment, choice, { tagError }) {
    const vars = { name: attachment.name, organization: choice.organizationName || "" };
    if (tagError) api.toast.warning(t("done.saved_tag_failed", { ...vars, error: errorText(t, tagError) }));
    else if (choice.missingDefaults?.length) api.toast.warning(t("done.saved_missing_tags", { ...vars, tags: choice.missingDefaults.join(", ") }));
    else api.toast.success(t("done.saved", vars));
  }
  async function attachFlow(context) {
    const composerId = context?.composerId;
    if (!composerId) return null;
    let progress = null;
    try {
      const ready = await ensureConnection();
      if (!ready) return null;
      const { connection, canReadTags } = ready;
      const choice = await api.ui.openDialog({
        title: t("pick.title"),
        slot: "plugin-dialog",
        width: 640,
        extraProps: {
          view: "pick",
          connection,
          canReadTags,
          organizationId: await api.storage.get(DEFAULT_ORGANIZATION_KEY).catch(() => null)
        }
      });
      const documents = Array.isArray(choice?.documents) ? choice.documents : [];
      if (!choice?.organizationId || !documents.length) return null;
      const total = documents.reduce((n, d) => n + (Number(d.size) || 0), 0);
      if (total >= PROGRESS_FROM_BYTES) progress = await showProgress(t("pick.attaching", { count: documents.length }));
      const attached = await attachDocuments({ api, client: clientFor(api, connection), organizationId: choice.organizationId, documents, composerId });
      hideProgress(progress);
      api.toast.success(attached.length === 1 ? t("pick.attached_one", { name: attached[0] }) : t("pick.attached", { count: attached.length }));
      return attached;
    } catch (err) {
      hideProgress(progress);
      const e = toPapraError(err);
      const done = Array.isArray(err?.attached) ? err.attached.length : 0;
      api.toast.error(done ? t("pick.partly", { count: done, error: errorText(t, e) }) : errorText(t, e));
      return null;
    }
  }
  function onAction({ actionId, context } = {}) {
    if (actionId === ACTION_SAVE) return saveFlow(context);
    if (actionId === ACTION_ATTACH) return attachFlow(context);
    return null;
  }
  async function registerUi() {
    const entries = [
      ["attachment-menu", [{ id: ACTION_SAVE, label: t("action.save"), icon: "archive" }]],
      ["composer-attach-menu", [{ id: ACTION_ATTACH, label: t("action.attach"), icon: "archive" }]]
    ];
    await Promise.all(entries.map(([surface, actions]) => Promise.resolve().then(() => api.ui.setActions(surface, actions)).catch((err) => api.log?.warn?.(`setting up ${surface} failed`, err?.message))));
  }
  return { onAction, registerUi, saveFlow, attachFlow };
}

// papra/src/ui/host.js
var current = null;
function setApi(api) {
  current = api;
}
function getApi() {
  if (current) return current;
  current = require("@plugin-host");
  return current;
}
function formatSize(bytes) {
  const n = Number(bytes) || 0;
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(n < 10 * 1024 ? 1 : 0)} KB`;
  return `${(n / 1024 / 1024).toFixed(1)} MB`;
}

// papra/src/ui/SaveDialog.jsx
var import_react = require("react");
var import_ui = require("@plugin-host/ui");

// papra/src/ui/organizations.js
function preselect(organizations, defaultId) {
  if (defaultId && organizations.some((o) => o.id === defaultId)) return defaultId;
  return organizations.length === 1 ? organizations[0].id : null;
}
function organizationOptions(organizations, selected, t) {
  const options = organizations.map((o) => ({ value: o.id, label: o.name }));
  return selected ? options : [{ value: "", label: t("field.organization_choose") }, ...options];
}

// papra/src/ui/SaveDialog.jsx
var import_jsx_runtime = require("react/jsx-runtime");
function SaveDialog({ api = getApi(), attachment = {}, connection, canTag = false, defaultTags = [], organizationId = null, onResult }) {
  const t = (key, vars) => api.i18n.t(key, vars);
  const client = (0, import_react.useMemo)(() => clientFor(api, connection), [api, connection]);
  const [organizations, setOrganizations] = (0, import_react.useState)(null);
  const [selected, setSelected] = (0, import_react.useState)(null);
  const [tags, setTags] = (0, import_react.useState)(null);
  const [picked, setPicked] = (0, import_react.useState)(() => /* @__PURE__ */ new Set());
  const [error, setError] = (0, import_react.useState)(null);
  const [attempt, setAttempt] = (0, import_react.useState)(0);
  (0, import_react.useEffect)(() => {
    let cancelled = false;
    setError(null);
    client.organizations().then((list) => {
      if (cancelled) return;
      setOrganizations(list);
      setSelected((prev) => prev || preselect(list, organizationId));
    }, (err) => {
      if (!cancelled) setError(err);
    });
    return () => {
      cancelled = true;
    };
  }, [client, organizationId, attempt]);
  (0, import_react.useEffect)(() => {
    if (!selected || !canTag) return void 0;
    let cancelled = false;
    setTags(null);
    setPicked(/* @__PURE__ */ new Set());
    client.tags(selected).then((list) => {
      if (!cancelled) setTags(list);
    }, (err) => {
      if (!cancelled) setError(err);
    });
    return () => {
      cancelled = true;
    };
  }, [client, selected, canTag, attempt]);
  const defaults = (0, import_react.useMemo)(() => matchTags(defaultTags, tags || []), [defaultTags, tags]);
  const defaultIds = new Set(defaults.tags.map((tag) => tag.id));
  const organization = organizations?.find((o) => o.id === selected);
  const ready = !!organization && (!canTag || !!tags);
  const toggle = (id) => setPicked((prev) => {
    const next = new Set(prev);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    return next;
  });
  const submit = () => {
    if (!ready) return;
    onResult?.({
      organizationId: organization.id,
      organizationName: organization.name,
      tagIds: canTag ? [...defaultIds, ...[...picked].filter((id) => !defaultIds.has(id))] : [],
      missingDefaults: canTag ? defaults.missing : []
    });
  };
  const buttons = [
    { id: "cancel", label: t("common.cancel"), variant: "secondary" },
    { id: "save", label: t("save.button"), variant: "primary", disabled: !ready }
  ];
  const onButton = (id) => id === "save" ? submit() : onResult?.(null);
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_ui.Stack, { gap: 4, children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Text, { tone: "muted", children: t("save.file", { name: attachment.name || "", size: formatSize(attachment.size) }) }),
    error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Alert, { tone: "danger", icon: "alert-circle", action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.LinkButton, { onClick: () => setAttempt((n) => n + 1), children: t("common.retry") }), children: errorText(t, error) }),
    !organizations && !error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Spinner, { size: "sm", label: t("common.loading") }),
    organizations && organizations.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Alert, { tone: "warning", icon: "alert-triangle", children: t("save.no_organizations") }),
    organizations && organizations.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Field, { label: t("field.organization"), children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
      import_ui.Select,
      {
        block: true,
        value: selected || "",
        onChange: (value) => setSelected(value || null),
        options: organizationOptions(organizations, selected, t)
      }
    ) }),
    organization && !canTag && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Alert, { tone: "info", icon: "info-circle", children: t("save.cannot_tag") }),
    organization && canTag && !tags && !error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Spinner, { size: "sm", label: t("common.loading") }),
    organization && canTag && tags && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { role: "group", "aria-label": t("field.tags"), children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_ui.Stack, { gap: 2, children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Text, { children: t("field.tags") }),
      tags.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Text, { tone: "muted", children: t("save.no_tags") }),
      tags.map((tag) => defaultIds.has(tag.id) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Checkbox, { checked: true, disabled: true, label: tag.name, hint: t("save.default_tag"), onChange: () => {
      } }, tag.id) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Checkbox, { checked: picked.has(tag.id), label: tag.name, onChange: () => toggle(tag.id) }, tag.id)),
      defaults.missing.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Text, { tone: "muted", children: t("save.missing_defaults", { tags: defaults.missing.join(", "), organization: organization.name }) })
    ] }) }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.DialogButtons, { buttons, onClick: onButton })
  ] });
}

// papra/src/ui/PickDialog.jsx
var import_react2 = require("react");
var import_ui2 = require("@plugin-host/ui");
var import_jsx_runtime2 = require("react/jsx-runtime");
var SEARCH_DELAY_MS = 300;
var PAGE = 25;
function PickDialog({ api = getApi(), connection, canReadTags = false, organizationId = null, onResult }) {
  const t = (key, vars) => api.i18n.t(key, vars);
  const client = (0, import_react2.useMemo)(() => clientFor(api, connection), [api, connection]);
  const [organizations, setOrganizations] = (0, import_react2.useState)(null);
  const [selected, setSelected] = (0, import_react2.useState)(null);
  const [text, setText] = (0, import_react2.useState)("");
  const [query, setQuery] = (0, import_react2.useState)("");
  const [tagFilters, setTagFilters] = (0, import_react2.useState)([]);
  const [orgTags, setOrgTags] = (0, import_react2.useState)([]);
  const [results, setResults] = (0, import_react2.useState)(null);
  const [page, setPage] = (0, import_react2.useState)(0);
  const [picked, setPicked] = (0, import_react2.useState)(() => /* @__PURE__ */ new Map());
  const [error, setError] = (0, import_react2.useState)(null);
  const [attempt, setAttempt] = (0, import_react2.useState)(0);
  (0, import_react2.useEffect)(() => {
    let cancelled = false;
    setError(null);
    client.organizations().then((list) => {
      if (cancelled) return;
      setOrganizations(list);
      setSelected((prev) => prev || preselect(list, organizationId));
    }, (err) => {
      if (!cancelled) setError(err);
    });
    return () => {
      cancelled = true;
    };
  }, [client, organizationId, attempt]);
  (0, import_react2.useEffect)(() => {
    setTagFilters([]);
    setPicked(/* @__PURE__ */ new Map());
    setOrgTags([]);
    if (!selected || !canReadTags) return void 0;
    let cancelled = false;
    client.tags(selected).then((list) => {
      if (!cancelled) setOrgTags(list);
    }, () => {
    });
    return () => {
      cancelled = true;
    };
  }, [client, selected, canReadTags]);
  (0, import_react2.useEffect)(() => {
    const timer = setTimeout(() => setQuery(text.trim()), SEARCH_DELAY_MS);
    return () => clearTimeout(timer);
  }, [text]);
  (0, import_react2.useEffect)(() => {
    setPage(0);
  }, [selected, query, tagFilters]);
  (0, import_react2.useEffect)(() => {
    if (!selected) return void 0;
    let cancelled = false;
    setError(null);
    if (page === 0) setResults(null);
    client.searchDocuments(selected, { text: query, tags: tagFilters }, page, PAGE).then((found) => {
      if (cancelled) return;
      setResults((prev) => page === 0 || !prev ? found : { count: found.count, documents: [...prev.documents, ...found.documents] });
    }, (err) => {
      if (!cancelled) setError(err);
    });
    return () => {
      cancelled = true;
    };
  }, [client, selected, query, tagFilters, page, attempt]);
  const toggle = (doc) => setPicked((prev) => {
    const next = new Map(prev);
    if (next.has(doc.id)) next.delete(doc.id);
    else next.set(doc.id, doc);
    return next;
  });
  const addTag = (name) => {
    if (name && !tagFilters.includes(name)) setTagFilters([...tagFilters, name]);
  };
  const removeTag = (name) => setTagFilters(tagFilters.filter((n) => n !== name));
  const date = (doc) => {
    const value = doc.documentDate || doc.createdAt;
    return value ? api.i18n.formatDate(value, { year: "numeric", month: "short", day: "numeric" }) : "";
  };
  const tooLarge = (doc) => doc.size > MAX_DOCUMENT_BYTES;
  const submit = () => {
    if (!picked.size || !selected) return;
    onResult?.({
      organizationId: selected,
      documents: [...picked.values()].map(({ id, name, mimeType, size }) => ({ id, name, mimeType, size }))
    });
  };
  const buttons = [
    { id: "cancel", label: t("common.cancel"), variant: "secondary" },
    { id: "attach", label: picked.size > 1 ? t("pick.button_count", { count: picked.size }) : t("pick.button"), variant: "primary", disabled: !picked.size }
  ];
  const unusedTags = orgTags.filter((tag) => !tagFilters.includes(tag.name));
  return /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)(import_ui2.Stack, { gap: 4, children: [
    error && /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.Alert, { tone: "danger", icon: "alert-circle", action: /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.LinkButton, { onClick: () => setAttempt((n) => n + 1), children: t("common.retry") }), children: errorText(t, error) }),
    !organizations && !error && /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.Spinner, { size: "sm", label: t("common.loading") }),
    organizations && organizations.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.Alert, { tone: "warning", icon: "alert-triangle", children: t("save.no_organizations") }),
    organizations && organizations.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.Field, { label: t("field.organization"), children: /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(
      import_ui2.Select,
      {
        block: true,
        value: selected || "",
        onChange: (value) => setSelected(value || null),
        options: organizationOptions(organizations, selected, t)
      }
    ) }),
    selected && /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)(import_jsx_runtime2.Fragment, { children: [
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.SearchInput, { value: text, onChange: setText, label: t("pick.search"), placeholder: t("pick.search_placeholder") }),
      canReadTags && unusedTags.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.Field, { label: t("pick.tag_filter"), children: /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(
        import_ui2.Select,
        {
          block: true,
          value: "",
          onChange: addTag,
          options: [{ value: "", label: t("pick.tag_any") }, ...unusedTags.map((tag) => ({ value: tag.name, label: tag.name }))]
        }
      ) }),
      tagFilters.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("div", { role: "group", "aria-label": t("pick.tag_filter"), children: /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.Row, { gap: 2, children: tagFilters.map((name) => /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.Chip, { label: name, onRemove: () => removeTag(name), removeLabel: t("pick.remove_tag", { tag: name }) }, name)) }) }),
      picked.size > 0 && /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("div", { role: "group", "aria-label": t("pick.picked"), children: /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)(import_ui2.Stack, { gap: 2, children: [
        /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.Text, { tone: "muted", children: t("pick.picked") }),
        /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.Row, { gap: 2, children: [...picked.values()].map((doc) => /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.Chip, { label: doc.name, onRemove: () => toggle(doc), removeLabel: t("pick.unpick", { name: doc.name }) }, doc.id)) })
      ] }) }),
      !results && !error && /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.Spinner, { size: "sm", label: t("common.loading") }),
      results && results.documents.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.Text, { tone: "muted", children: t("pick.none") }),
      results && results.documents.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)(import_jsx_runtime2.Fragment, { children: [
        /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.Text, { tone: "muted", children: results.count === 1 ? t("pick.count_one") : t("pick.count", { count: results.count }) }),
        /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.List, { label: t("pick.results"), children: results.documents.map((doc) => /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(
          import_ui2.ListRow,
          {
            icon: doc.name,
            title: doc.name,
            subtitle: [...doc.tags.map((tag) => tag.name), tooLarge(doc) ? t("pick.too_large") : ""].filter(Boolean).join(" · "),
            meta: [date(doc), formatSize(doc.size)].filter(Boolean),
            checked: picked.has(doc.id),
            onCheck: () => toggle(doc),
            onClick: () => toggle(doc),
            disabled: tooLarge(doc)
          },
          doc.id
        )) }),
        results.documents.length < results.count && /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.LinkButton, { onClick: () => setPage((p) => p + 1), children: t("pick.more") })
      ] })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.DialogButtons, { buttons, onClick: (id) => id === "attach" ? submit() : onResult?.(null) })
  ] });
}

// papra/src/ui/Settings.jsx
var import_react3 = require("react");
var import_ui3 = require("@plugin-host/ui");
var import_jsx_runtime3 = require("react/jsx-runtime");
var hostOf2 = (url) => {
  try {
    return new URL(url).host;
  } catch {
    return String(url || "");
  }
};
function Settings({ api = getApi() }) {
  const t = (key2, vars) => api.i18n.t(key2, vars);
  const [connection, setConnection] = (0, import_react3.useState)(null);
  const [key, setKey] = (0, import_react3.useState)(null);
  const [organizations, setOrganizations] = (0, import_react3.useState)(null);
  const [defaultId, setDefaultId] = (0, import_react3.useState)("");
  const [error, setError] = (0, import_react3.useState)(null);
  const [busy, setBusy] = (0, import_react3.useState)(false);
  const load = (0, import_react3.useCallback)(async () => {
    setError(null);
    setKey(null);
    setOrganizations(null);
    const next = await resolveConnection(api);
    setConnection(next);
    setDefaultId(await api.storage.get(DEFAULT_ORGANIZATION_KEY).catch(() => null) || "");
    if (next.state !== "connected") return;
    try {
      const client = clientFor(api, next);
      const current2 = await client.currentKey();
      setKey({ name: current2.name, ...keyAbilities(current2.permissions) });
      setOrganizations(await client.organizations());
    } catch (err) {
      setError(err);
    }
  }, [api]);
  (0, import_react3.useEffect)(() => {
    void load();
  }, [load]);
  const onConnect = async () => {
    setBusy(true);
    setError(null);
    try {
      const result = await connect(api);
      if (result.error) setError(result.error);
      if (result.connected) await load();
    } catch (err) {
      setError(err);
    } finally {
      setBusy(false);
    }
  };
  const onDisconnect = async () => {
    setBusy(true);
    try {
      await api.proxy.disconnect(CREDENTIAL);
      await load();
    } catch (err) {
      setError(err);
    } finally {
      setBusy(false);
    }
  };
  const onDefault = async (value) => {
    setError(null);
    try {
      if (value) await api.storage.set(DEFAULT_ORGANIZATION_KEY, value);
      else await api.storage.remove(DEFAULT_ORGANIZATION_KEY);
      setDefaultId(value || "");
    } catch (err) {
      setError(err);
    }
  };
  if (!connection) return /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(import_ui3.Loading, { label: t("common.loading") });
  const host = hostOf2(connection.server);
  const shownDefault = organizations?.some((o) => o.id === defaultId) ? defaultId : "";
  return /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)(import_ui3.Stack, { gap: 4, children: [
    /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(import_ui3.Section, { title: t("settings.connection"), children: /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)(import_ui3.Stack, { gap: 3, children: [
      connection.state === "not_configured" && /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(import_ui3.Alert, { tone: "info", icon: "info-circle", children: t("settings.not_configured") }),
      connection.state === "disconnected" && /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)(import_jsx_runtime3.Fragment, { children: [
        connection.wrongServer && /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(import_ui3.Alert, { tone: "warning", icon: "alert-triangle", children: t("settings.wrong_server", { server: hostOf2(connection.wrongServer), host }) }),
        /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(import_ui3.Text, { children: t("settings.disconnected", { host }) }),
        /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(import_ui3.Button, { busy, onClick: onConnect, children: t("connect.title") }) })
      ] }),
      connection.state === "connected" && /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)(import_jsx_runtime3.Fragment, { children: [
        /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(import_ui3.Text, { children: t("settings.connected", { host, name: key?.name || "…" }) }),
        key && key.missing.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(import_ui3.Alert, { tone: "warning", icon: "alert-triangle", children: t("settings.missing", { missing: key.missing.join(", ") }) }),
        key && key.missing.length === 0 && !key.canTag && /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(import_ui3.Text, { tone: "muted", children: t("settings.cannot_tag") }),
        /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(import_ui3.Button, { variant: "secondary", busy, onClick: onDisconnect, children: t("settings.disconnect") }) })
      ] }),
      error && /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(import_ui3.Alert, { tone: "danger", icon: "alert-circle", children: errorText(t, error) })
    ] }) }),
    connection.state === "connected" && organizations && organizations.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(import_ui3.Section, { title: t("settings.default_organization"), children: /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(import_ui3.Field, { label: t("field.organization"), hint: t("settings.default_organization_hint"), children: /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(
      import_ui3.Select,
      {
        block: true,
        value: shownDefault,
        onChange: onDefault,
        options: [{ value: "", label: t("settings.no_default") }, ...organizations.map((o) => ({ value: o.id, label: o.name }))]
      }
    ) }) })
  ] });
}

// papra/src/index.js
var background = null;
async function activate(api) {
  setApi(api);
  background = createBackground(api);
  await background.registerUi();
  api.i18n.onLocaleChange(() => {
    void background.registerUi();
  });
}
var hooks = {
  onAction(event) {
    if (background) void Promise.resolve(background.onAction(event)).catch(() => {
    });
  }
};
function Dialog(props) {
  if (props.view === "save") return (0, import_react4.createElement)(SaveDialog, props);
  if (props.view === "pick") return (0, import_react4.createElement)(PickDialog, props);
  return null;
}
var slots = {
  "plugin-dialog": { component: Dialog },
  "settings-section": { component: () => (0, import_react4.createElement)(Settings, {}) }
};
